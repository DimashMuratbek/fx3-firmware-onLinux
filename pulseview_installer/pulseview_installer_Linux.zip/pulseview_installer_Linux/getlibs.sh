#! /bin/bash

# Clone libsigrok
git clone https://github.com/DimashMuratbek/libsigrok.git

# Clone libsigrokdecode
git clone https://github.com/sigrokproject/libsigrokdecode.git

# Clone pulseview
git clone https://github.com/sigrokproject/pulseview.git

# install libsigrok
pushd libsigrok
./autogen.sh
./configure
make
popd

# install libsigrokdecode
pushd libsigrokdecode
./autogen.sh
./configure
make
popd

# install pulseview
pushd pulseview
cmake .
make
popd

